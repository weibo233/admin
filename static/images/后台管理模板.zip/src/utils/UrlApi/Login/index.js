import request from "../../HttpServe";
module.exports = {
  Login:function (data){
      return request({
        url: '/login',
        method:'post',
        data
      })
    },
}

