<template>
  <div>
    金点子One
  </div>
</template>

<script>
import fn from '@/utils/UrlApi/Login'

  export default {
    name:'goldIdea',
    created(){
      this.errMsg("laji")
    },
    methods:{
    }
  }
</script>

<style lang="scss" scoped>

</style>