<template>
  <div>
    今日随笔One
  </div>
</template>

<script>
  export default {
    name:"TodayEssay"
  }
</script>

<style lang="scss" scoped>

</style>