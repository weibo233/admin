import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path:'/login',
      name: 'login',
      meta:{
        isNav:false
      },
      components:{
        default: ()=>import("../view/login")
      }
    },
    {
      path:'/register',
      name: 'register',
      meta:{
        isNav:false
      },
      components:{
        default: ()=>import("../view/register")
      }
    },
    {
      path: '/',
      redirect: '/welcome',
      meta:{
        isNav:false
      }
    },
    // welcome
    {
      path: '/welcome',
      name: 'welcome',
      meta: {
        default: "0",
        isNav:false
      },
      components: {
        default: () => import("../components/layout/index")
      },
      redirect:"/welcome/home",
      children: [
        {
          path: '/welcome/home',
          name: 'welcomeHome',
          meta: {
            default: "0"
          },
          components: {
            default: () => import("../view/welcome")
          },
        }
      ]
    },
    /**
   * title      一级菜单名字
   * childTitle 子级路由名字
   * default    默认展开导航
   */
    // 账单首页
    {
      path: '/billHome',
      name: 'billHome',
      meta: {
        default: "1",
        title: '账单首页',
        isNav: true,
        icon: 'iconfont el-icon-s-help'
      },
      components: {
        default: () => import("../components/layout/index")
      },
      children: [
        {
          path: '/billHome/One',
          name: 'billHomeOne',
          meta: {
            childTitle: '账单首页',
            default: '1-1',
            parentDefault: '1',
          },
          components: {
            default: () => import("../view/billHome")
          },
        },
        // {
        //   path: '/billHome/Two',
        //   name: 'billHomeTwo',
        //   meta: {
        //     childTitle: '账单首页Two',
        //     default: '1-2',
        //     parentDefault: '1',
        //   },
        //   components: {
        //     default: () => import("../view/billHome")
        //   },
        // },
      ]
    },
    // // 账单管理
    {
      path: '/BillManagement',
      name: 'BillManagement',
      meta: {
        default: "2",
        title: '账单管理',
        isNav: true,
        icon: 'iconfont el-icon-s-help'
      },
      components: {
        default: () => import("../components/layout/index")
      },
      children: [
        {
          path: '/BillManagement/One',
          name: 'BillManagementOne',
          meta: {
            childTitle: '账单管理',
            default: '2-1',
            parentDefault: '2',
          },
          components: {
            default: () => import("../view/BillManagement")
          },
        },
        {
          path: '/BillManagement/Two',
          name: 'BillManagementTwo',
          meta: {
            childTitle: '账单分析',
            default: '2-2',
            parentDefault: '2',
          },
          components: {
            default: () => import("../view/BillManagement")
          },
        },
      ]
    },

    // // 金点子
    {
      path: '/goldIdea',
      name: 'goldIdea',
      meta: {
        default: "3",
        title: '金点子',
        isNav: true,
        icon: 'iconfont el-icon-s-help'
      },
      components: {
        default: () => import("../components/layout/index")
      },
      children: [
        {
          path: '/goldIdea/One',
          name: 'goldIdeaOne',
          meta: {
            childTitle: '投资计划',
            default: '3-1',
            parentDefault: '3',
          },
          components: {
            default: () => import("../view/goldIdea")
          },
        },
        {
          path: '/goldIdea/Two',
          name: 'goldIdeaTwo',
          meta: {
            childTitle: '现有投资',
            default: '3-2',
            parentDefault: '3',
          },
          components: {
            default: () => import("../view/goldIdea")
          },
        },
        {
          path: '/goldIdea/Thorw',
          name: 'goldIdeaThorw',
          meta: {
            childTitle: '投资分析',
            default: '3-3',
            parentDefault: '3',
          },
          components: {
            default: () => import("../view/goldIdea")
          },
        },
      ]
    },

    // // 今日随笔
    {
      path: '/TodayEssay',
      name: 'TodayEssay',
      meta: {
        default: "4",
        title: '今日随笔',
        isNav: true,
        icon: 'iconfont el-icon-s-help'
      },
      components: {
        default: () => import("../components/layout/index")
      },
      children: [
        {
          path: '/TodayEssay/One',
          name: 'TodayEssayOne',
          meta: {
            childTitle: '随笔管理',
            default: '4-1',
            parentDefault: '4',
          },
          components: {
            default: () => import("../view/TodayEssay")
          },
        },
        {
          path: '/TodayEssay/Two',
          name: 'TodayEssayTwo',
          meta: {
            childTitle: '随笔小计',
            default: '4-2',
            parentDefault: '4',
          },
          components: {
            default: () => import("../view/TodayEssay")
          },
        }
      ]
    }
  ]
})
