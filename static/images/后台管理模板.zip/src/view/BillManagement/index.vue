<template>
  <div>
    账单管理One
  </div>
</template>

<script>
  export default {
    name:"BillManagement"
  }
</script>

<style lang="scss" scoped>

</style>