const API = {
  login: '/login'
}
export default API;