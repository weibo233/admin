<template>
  <div>
    账单首页One
  </div>
</template>

<script>
  export default {
    name:'billHome'
  }
</script>

<style lang="scss" scoped>

</style>