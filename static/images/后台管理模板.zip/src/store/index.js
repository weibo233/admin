import Vue from 'vue'
import Vuex from 'vuex'
import layOut from './layOut'
Vue.use(Vuex);

const store = new Vuex.Store({
    state: {
       
    },
    mutations:{
        
    },
    actions:{
       
    },
    getters: {
        
    },
    modules:{
        layOut
    }
})

export default store;