<template>
  <div class="login">
      <el-button type="primary" size="mini" @click="downZip">下载模板</el-button>
    <div class="formInput">
      <el-form
        :model="ruleForm"
        ref="ruleForm"
        label-width="100px"
        class="demo-ruleForm"
        :rules="relus"
      >
        <el-form-item label="账号" prop="username">
          <el-input type="text" v-model.number="ruleForm.username" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input type="password" v-model.number="ruleForm.password" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="password2" >
          <el-input type="password" @keyup.native.enter="submitForm('ruleForm')" v-model.number="ruleForm.password2" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submitForm('ruleForm')">确定</el-button>
          <el-button @click="resetForm('ruleForm')">取消</el-button>
          <el-button type="warning" @click="goRegister">去注册</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
import {Login} from '@/utils/UrlApi/Login'
export default {
  data() {
    return {
      ruleForm: {
        username: "",
        password: "",
        password2: ""
      },
      relus: {
       
        username: [
          { validator: this.validateUsername, required: true, trigger: "blur" }
        ],
        password: [
          { validator: this.validatePassword, required: true, trigger: "blur" }
        ],
        password2: [
          { validator: this.validatePassword2, required: true, trigger: "blur" }
        ]
      }
    };
  },
  created(){
  },
  methods: {
    downZip(){
      
    },
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.successMsg('登陆成功')
          sessionStorage.setItem("userInfo", `{username:${this.ruleForm.username},password:${this.ruleForm.password},name:${this.ruleForm.username}}`) //正常后端会返回注册的用户名
          this.$router.push("/")

          // Login(this.ruleForm).then(data=>{
          //   if(data.data.status){
          //     this.errMsg(data.data.status)
          //   }else{
          //     this.successMsg('登陆成功')
          //     sessionStorage.setItem("userInfo",JSON.stringify(data.data[0]) )
          //     this.$router.push("/")
          //   }
          // }).catch(err=>{

          // })

        } else {
          // 验证不通过
          console.log("error submit!!");
          return false;
        }
      });
    },
    goRegister(){
      this.$router.push({name:'register'})
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
   
    validateUsername(rule, value, callback) {
      if (value === "") {
        callback(new Error("请输入账号"));
      } else {
        if ((value + "").length < 6) {
          callback(new Error("账号长度最少为6位"));
        } else {
          if (this.ruleForm.username !== "") {
            this.$refs.ruleForm.validateField("checkPass");
          }
          callback();
        }
      }
    },
    validatePassword(rule, value, callback) {
      if (value === "") {
        callback(new Error("请输入密码"));
      } else if ((value + "").length < 6) {
        callback(new Error("密码长度最少为6位!"));
      } else {
        callback();
      }
    },
    validatePassword2(rule, value, callback) {
      if (value === "") {
        callback(new Error("请再次输入密码"));
      } else if (value !== this.ruleForm.password) {
        callback(new Error("两次输入密码不一致!"));
      } else {
        callback();
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.login {
  width: 100%;
  height: 100%;
  background: #ccc;
  color: #fff;
  background-image: url(../../assets/images/loginBg.jpg);
  background-size: 100% 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  .formInput {
    width: 600px;
    height: 300px;
    transform: translateY(110px);
  }
}
</style>